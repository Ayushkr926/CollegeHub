import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/club_provider.dart';
import 'screens/discover_clubs_screen.dart';
import 'theme/app_colors.dart';

void main() {
  runApp(const CampusEliteApp());
}

class CampusEliteApp extends StatelessWidget {
  const CampusEliteApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => ClubProvider(),
      child: MaterialApp(
        title: 'Campus Elite',
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark(useMaterial3: true).copyWith(
          scaffoldBackgroundColor: AppColors.background,
          textSelectionTheme: const TextSelectionThemeData(
            cursorColor: Colors.white,
          ),
        ),
        home: const DiscoverClubsScreen(),
      ),
    );
  }
}
