import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  static const Color background = Color(0xFF0A0A0C);
  static const Color surface = Color(0xFF15151A);
  static const Color surfaceElevated = Color(0xFF1C1C22);
  static const Color border = Color(0xFF2A2A31);

  static const Color textPrimary = Colors.white;
  static const Color textMuted = Color(0xFF9A9AA2);
  static const Color textFaint = Color(0xFF6C6C76);

  static const Color chipActiveBg = Colors.white;
  static const Color chipActiveFg = Colors.black;
  static const Color chipInactiveBg = Color(0xFF1C1C22);

  static const Color badgeBg = Color(0x40FFFFFF);

  static const Color joinButton = Colors.white;
}
